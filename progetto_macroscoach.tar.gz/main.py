from datetime import datetime, timedelta
from typing import Optional

import requests
from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import func
from sqlalchemy.orm import Session

from db import Base, engine, get_db
from models import (
    User,
    Food,
    Meal,
    MealItem,
    Workout,
    Set,
    WeightLog,
    RecentFood,
    UserPlan,
    UserDistribution,
)
from schemas import MealIn, WeightIn, WorkoutIn, PlanPayload

load_dotenv()
app = FastAPI(title="MacrosCoach API")

# ---------------- CORS (dev: all) ----------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # in prod: limita ai tuoi domini/app
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------- DB init ----------------
Base.metadata.create_all(bind=engine)

# ---------------- Health ----------------
@app.get("/health")
def health():
    return {"ok": True}

# ---------------- Helper ----------------
def ensure_user(db: Session, user_id: int) -> User:
    """
    Ritorna l'utente richiesto; se non esiste lo crea o usa/crea l'utente demo.
    """
    u = db.get(User, user_id)
    if u:
        return u
    demo = db.query(User).filter_by(email="demo@example.com").first()
    if demo and demo.id == user_id:
        return demo
    if not demo:
        demo = User(email="demo@example.com")
        db.add(demo)
        db.commit()
        db.refresh(demo)
    return demo

# ---------------- Users ----------------
@app.post("/users/demo")
def create_demo_user(db: Session = Depends(get_db)):
    u = db.query(User).filter_by(email="demo@example.com").first()
    if not u:
        u = User(email="demo@example.com")
        db.add(u)
        db.commit()
        db.refresh(u)
    return {"user_id": u.id}

# ---------------- Barcode / OFF lookup ----------------
@app.get("/foods/barcode/{code}")
def food_by_barcode(code: str):
    """
    Lookup barcode su OpenFoodFacts con fallbacks multipli.
    Restituisce: { name, per_100g: {kcal, pro, carb, fat} }
    """
    def extract_payload(p):
        if not p:
            return None
        nutr = p.get("nutriments", {}) or {}
        kcal = nutr.get("energy-kcal_100g")
        if kcal is None:
            energy_kj = nutr.get("energy_100g")
            if energy_kj is not None:
                try:
                    kcal = float(energy_kj) / 4.184
                except Exception:
                    kcal = None

        def fget(k):
            v = nutr.get(k)
            try:
                return None if v is None else float(v)
            except Exception:
                return None

        name = p.get("product_name") or p.get("brands") or p.get("generic_name") or "Prodotto"
        return {
            "name": name,
            "per_100g": {
                "kcal": None if kcal is None else round(kcal, 1),
                "pro": fget("proteins_100g"),
                "carb": fget("carbohydrates_100g"),
                "fat": fget("fat_100g"),
            },
        }

    # 1) v2 /product
    try:
        r = requests.get(f"https://world.openfoodfacts.org/api/v2/product/{code}.json", timeout=10)
        j = r.json()
        if j.get("status") == 1 and "product" in j:
            out = extract_payload(j["product"])
            if out:
                return out
    except requests.RequestException:
        pass

    # 2) v0 /product
    try:
        r0 = requests.get(f"https://world.openfoodfacts.org/api/v0/product/{code}.json", timeout=10)
        j0 = r0.json()
        if j0.get("status") == 1 and "product" in j0:
            out = extract_payload(j0["product"])
            if out:
                return out
    except requests.RequestException:
        pass

    # 3) v2 /search?code=
    try:
        rs2 = requests.get(f"https://world.openfoodfacts.org/api/v2/search?code={code}&page_size=1", timeout=10)
        js2 = rs2.json()
        prods = js2.get("products", []) or []
        if prods:
            out = extract_payload(prods[0])
            if out:
                return out
    except requests.RequestException:
        pass

    # 4) legacy CGI search
    try:
        rl = requests.get(
            f"https://world.openfoodfacts.org/cgi/search.pl?search_simple=1&json=1&code={code}&page_size=1",
            timeout=10,
        )
        jl = rl.json()
        prods = jl.get("products", []) or []
        if prods:
            out = extract_payload(prods[0])
            if out:
                return out
    except requests.RequestException:
        pass

    raise HTTPException(status_code=404, detail=f"Barcode non trovato su OFF (code={code})")

@app.get("/barcode/search")
def barcode_search(code: str):
    return food_by_barcode(code)

@app.post("/meals/add_from_barcode")
def add_meal_from_barcode(
    code: str = Query(..., description="Barcode prodotto"),
    grams: float = Query(..., description="Quantità in grammi"),
    slot: Optional[str] = None,
    when: Optional[datetime] = None,
    db: Session = Depends(get_db),
    user_id: int = Query(default=1),
):
    u = ensure_user(db, user_id)

    data = food_by_barcode(code)
    per100 = data["per_100g"] or {}

    # Trova o crea Food
    food = db.query(Food).filter_by(barcode=code).first()
    if not food:
        food = Food(
            name=data["name"],
            barcode=code,
            per_100g_kcal=per100.get("kcal") or 0,
            per_100g_pro=per100.get("pro") or 0,
            per_100g_carb=per100.get("carb") or 0,
            per_100g_fat=per100.get("fat") or 0,
        )
        db.add(food)
        db.flush()

    # Crea Meal + Item
    m = Meal(user_id=u.id, when=when or datetime.utcnow())
    db.add(m)
    db.flush()

    db.add(
        MealItem(
            meal_id=m.id,
            food_id=food.id,
            food_name=food.name,
            grams=grams,
            pro=food.per_100g_pro or 0,
            carb=food.per_100g_carb or 0,
            fat=food.per_100g_fat or 0,
        )
    )

    # Aggiorna recenti
    rf = db.query(RecentFood).filter_by(user_id=u.id, food_id=food.id).first()
    if rf:
        rf.last_used = datetime.utcnow()
    else:
        db.add(RecentFood(user_id=u.id, food_id=food.id))

    db.commit()
    return {"ok": True, "meal_id": m.id, "food": food.name, "grams": grams, "slot": slot}

@app.get("/foods/recent")
def foods_recent(
    limit: int = 10,
    db: Session = Depends(get_db),
    user_id: int = Query(default=1),
):
    u = ensure_user(db, user_id)
    rows = (
        db.query(RecentFood, Food)
        .join(Food, RecentFood.food_id == Food.id)
        .filter(RecentFood.user_id == u.id)
        .order_by(RecentFood.last_used.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "food_id": f.id,
            "name": f.name,
            "barcode": f.barcode,
            "per_100g": {
                "kcal": f.per_100g_kcal,
                "pro": f.per_100g_pro,
                "carb": f.per_100g_carb,
                "fat": f.per_100g_fat,
            },
        }
        for _, f in rows
    ]

# ---------------- Meals ----------------
@app.post("/meals")
def create_meal(meal: MealIn, db: Session = Depends(get_db), user_id: int = Query(default=1)):
    try:
        u = ensure_user(db, user_id)
        m = Meal(user_id=u.id, when=meal.when)
        db.add(m)
        db.flush()
        for it in meal.items:
            db.add(
                MealItem(
                    meal_id=m.id,
                    food_name=it.food_name,
                    grams=it.grams,
                    pro=it.pro,
                    carb=it.carb,
                    fat=it.fat,
                )
            )
        db.commit()
        return {"ok": True, "meal_id": m.id, "user_id": u.id}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Errore create_meal: {e}")

@app.get("/meals/today")
def meals_today(db: Session = Depends(get_db), user_id: int = Query(default=1)):
    u = ensure_user(db, user_id)
    d0 = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    d1 = d0 + timedelta(days=1)
    meals = db.query(Meal).filter(Meal.user_id == u.id, Meal.when >= d0, Meal.when < d1).all()
    result = []
    tot_pro = tot_carb = tot_fat = 0.0
    for m in meals:
        items = db.query(MealItem).filter(MealItem.meal_id == m.id).all()
        pro = sum(i.pro * (i.grams / 100.0) for i in items)
        carb = sum(i.carb * (i.grams / 100.0) for i in items)
        fat = sum(i.fat * (i.grams / 100.0) for i in items)
        kcal = pro * 4 + carb * 4 + fat * 9
        tot_pro += pro
        tot_carb += carb
        tot_fat += fat
        result.append(
            {
                "meal_id": m.id,
                "when": m.when.isoformat(),
                "kcal": kcal,
                "pro": pro,
                "carb": carb,
                "fat": fat,
            }
        )
    day = {"kcal": tot_pro * 4 + tot_carb * 4 + tot_fat * 9, "pro": tot_pro, "carb": tot_carb, "fat": tot_fat}
    return {"day_totals": day, "meals": result}

# ---------------- Weight ----------------
@app.post("/weight")
def add_weight(w: WeightIn, db: Session = Depends(get_db), user_id: int = Query(default=1)):
    try:
        u = ensure_user(db, user_id)
        db.add(WeightLog(user_id=u.id, when=w.when, kg=w.kg))
        db.commit()
        return {"ok": True, "user_id": u.id}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Errore add_weight: {e}")

@app.get("/weights/all")
def weights_all(db: Session = Depends(get_db), user_id: int = Query(default=1)):
    u = ensure_user(db, user_id)
    rows = db.query(WeightLog).filter(WeightLog.user_id == u.id).order_by(WeightLog.when.asc()).all()
    return [{"id": r.id, "when": r.when.isoformat(), "kg": r.kg} for r in rows]

@app.get("/weights/range")
def weights_range(
    start: str,
    end: str,
    db: Session = Depends(get_db),
    user_id: int = Query(default=1, description="ID utente"),
):
    """
    Restituisce tutte le pesate nel range [start, end).
    Accetta date (YYYY-MM-DD) o datetime ISO; end esclusivo se data.
    """
    u = ensure_user(db, user_id)
    # parse start
    try:
        d0 = datetime.fromisoformat(start)
    except Exception:
        try:
            d0 = datetime.fromisoformat(start + "T00:00:00")
        except Exception:
            raise HTTPException(status_code=400, detail="Formato start non valido. Usa YYYY-MM-DD o datetime ISO")
    # parse end
    try:
        d1 = datetime.fromisoformat(end)
    except Exception:
        try:
            d1 = datetime.fromisoformat(end + "T00:00:00") + timedelta(days=1)
        except Exception:
            raise HTTPException(status_code=400, detail="Formato end non valido. Usa YYYY-MM-DD o datetime ISO")

    rows = (
        db.query(WeightLog)
        .filter(WeightLog.user_id == u.id, WeightLog.when >= d0, WeightLog.when < d1)
        .order_by(WeightLog.when.asc())
        .all()
    )
    return [{"id": r.id, "when": r.when.isoformat(), "kg": r.kg} for r in rows]

@app.get("/weights/weekly")
def weights_weekly(
    db: Session = Depends(get_db),
    user_id: int = Query(default=1, description="ID utente"),
):
    u = ensure_user(db, user_id)
    rows = db.query(WeightLog).filter(WeightLog.user_id == u.id).order_by(WeightLog.when.asc()).all()
    if not rows:
        return []
    weekly = {}
    for r in rows:
        d = r.when.date()
        week_start = d - timedelta(days=d.weekday())  # lunedì
        key = week_start.isoformat()
        w = weekly.get(key, {"week_start": key, "values": []})
        w["values"].append(r.kg)
        weekly[key] = w
    out = []
    for k in sorted(weekly.keys()):
        vals = weekly[k]["values"]
        avg = sum(vals) / len(vals)
        out.append({"week_start": k, "avg": round(avg, 2), "min": min(vals), "max": max(vals), "n": len(vals)})
    return out

@app.get("/weights/trend")
def weights_trend(
    db: Session = Depends(get_db),
    user_id: int = Query(default=1, description="ID utente"),
):
    u = ensure_user(db, user_id)
    rows = db.query(WeightLog).filter(WeightLog.user_id == u.id).order_by(WeightLog.when.asc()).all()
    if len(rows) < 2:
        return {"slope_kg_per_week": None}

    x = []
    y = []
    t0 = rows[0].when
    for r in rows:
        days = (r.when - t0).total_seconds() / (60 * 60 * 24)  # giorni decimali
        x.append(days)
        y.append(r.kg)

    n = len(x)
    sumx, sumy = sum(x), sum(y)
    sumxy = sum(a * b for a, b in zip(x, y))
    sumx2 = sum(a * a for a in x)
    denom = n * sumx2 - sumx * sumx
    if denom == 0:
        return {"slope_kg_per_week": None}

    slope = (n * sumxy - sumx * sumy) / denom
    return {"slope_kg_per_week": round(slope * 7, 3)}  # variazione settimanale

# ---------------- Workouts ----------------
@app.post("/workouts")
def add_workout(w: WorkoutIn, db: Session = Depends(get_db), user_id: int = Query(default=1)):
    try:
        u = ensure_user(db, user_id)
        wk = Workout(user_id=u.id, when=w.when)
        db.add(wk)
        db.flush()
        for s in w.sets:
            db.add(Set(workout_id=wk.id, exercise=s.exercise, reps=s.reps, weight_kg=s.weight_kg))
        db.commit()
        return {"ok": True, "workout_id": wk.id, "user_id": u.id}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Errore add_workout: {e}")

@app.get("/workouts/all")
def workouts_all(db: Session = Depends(get_db), user_id: int = Query(default=1)):
    u = ensure_user(db, user_id)
    wks = db.query(Workout).filter(Workout.user_id == u.id).order_by(Workout.when.desc()).all()
    out = []
    for w in wks:
        sets = db.query(Set).filter(Set.workout_id == w.id).all()
        out.append(
            {
                "id": w.id,
                "when": w.when.isoformat(),
                "sets": [{"exercise": s.exercise, "reps": s.reps, "weight_kg": s.weight_kg} for s in sets],
            }
        )
    return out

# ---------------- Day / Week summaries ----------------
@app.get("/summary/day")
def summary_day(date: str, db: Session = Depends(get_db), user_id: int = Query(default=1)):
    u = ensure_user(db, user_id)
    try:
        d0 = datetime.fromisoformat(date)
    except Exception:
        raise HTTPException(status_code=400, detail="Formato data non valido. Usa YYYY-MM-DD")
    d1 = d0 + timedelta(days=1)

    pro = (
        db.query(func.sum(MealItem.pro * (MealItem.grams / 100.0)))
        .join(Meal)
        .filter(Meal.user_id == u.id, Meal.when >= d0, Meal.when < d1)
        .scalar()
        or 0.0
    )
    carb = (
        db.query(func.sum(MealItem.carb * (MealItem.grams / 100.0)))
        .join(Meal)
        .filter(Meal.user_id == u.id, Meal.when >= d0, Meal.when < d1)
        .scalar()
        or 0.0
    )
    fat = (
        db.query(func.sum(MealItem.fat * (MealItem.grams / 100.0)))
        .join(Meal)
        .filter(Meal.user_id == u.id, Meal.when >= d0, Meal.when < d1)
        .scalar()
        or 0.0
    )
    kcal = pro * 4 + carb * 4 + fat * 9
    return {"kcal": kcal, "pro": pro, "carb": carb, "fat": fat, "user_id": u.id}

@app.get("/summary/week")
def summary_week(start: str, db: Session = Depends(get_db), user_id: int = Query(default=1)):
    u = ensure_user(db, user_id)
    try:
        d0 = datetime.fromisoformat(start)
    except Exception:
        raise HTTPException(status_code=400, detail="Formato start non valido. Usa YYYY-MM-DD")
    d1 = d0 + timedelta(days=7)
    meals = db.query(Meal).filter(Meal.user_id == u.id, Meal.when >= d0, Meal.when < d1).all()
    tot_pro = tot_carb = tot_fat = 0.0
    for m in meals:
        items = db.query(MealItem).filter(MealItem.meal_id == m.id).all()
        tot_pro += sum(i.pro * (i.grams / 100.0) for i in items)
        tot_carb += sum(i.carb * (i.grams / 100.0) for i in items)
        tot_fat += sum(i.fat * (i.grams / 100.0) for i in items)
    tot_kcal = tot_pro * 4 + tot_carb * 4 + tot_fat * 9
    return {"week_start": start, "totals": {"kcal": tot_kcal, "pro": tot_pro, "carb": tot_carb, "fat": tot_fat}}

@app.get("/check/weekly")
def check_weekly(
    start: str,
    protein_target_g: float = 120.0,
    kcal_target: Optional[float] = None,
    min_workouts: int = 3,
    db: Session = Depends(get_db),
    user_id: int = Query(default=1),
):
    u = ensure_user(db, user_id)
    try:
        d0 = datetime.fromisoformat(start)
    except Exception:
        raise HTTPException(status_code=400, detail="Formato start non valido. Usa YYYY-MM-DD")
    d1 = d0 + timedelta(days=7)
    days = [d0 + timedelta(days=i) for i in range(7)]
    day_stats = []
    for day in days:
        d_end = day + timedelta(days=1)
        items = (
            db.query(MealItem)
            .join(Meal)
            .filter(Meal.user_id == u.id, Meal.when >= day, Meal.when < d_end)
            .all()
        )
        pro = sum(i.pro * (i.grams / 100.0) for i in items)
        carb = sum(i.carb * (i.grams / 100.0) for i in items)
        fat = sum(i.fat * (i.grams / 100.0) for i in items)
        kcal = pro * 4 + carb * 4 + fat * 9
        day_stats.append({"date": day.date().isoformat(), "kcal": kcal, "pro": pro, "carb": carb, "fat": fat})
    protein_days = sum(1 for d in day_stats if d["pro"] >= protein_target_g)
    kcal_days = None
    if kcal_target is not None:
        kcal_days = sum(1 for d in day_stats if abs(d["kcal"] - kcal_target) <= kcal_target * 0.1)
    workouts_count = (
        db.query(func.count(Workout.id))
        .filter(Workout.user_id == u.id, Workout.when >= d0, Workout.when < d1)
        .scalar()
        or 0
    )
    return {
        "week_start": start,
        "missions": [
            {"name": "Proteine", "days_hit": protein_days},
            {"name": "Allenamenti", "done": workouts_count, "target": min_workouts},
        ],
        "daily": day_stats,
        "kcal_days_within_±10%": kcal_days,
    }

# ---------------- Deletes ----------------
@app.delete("/meals/{meal_id}")
def delete_meal(
    meal_id: int,
    db: Session = Depends(get_db),
    user_id: int = Query(default=1),
):
    u = ensure_user(db, user_id)
    m = db.query(Meal).filter(Meal.id == meal_id, Meal.user_id == u.id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Meal non trovato per questo utente")
    try:
        db.query(MealItem).filter(MealItem.meal_id == m.id).delete(synchronize_session=False)
        db.delete(m)
        db.commit()
        return {"ok": True, "deleted_meal_id": meal_id}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Errore delete_meal: {e}")

@app.delete("/weights/{weight_id}")
def delete_weight(
    weight_id: int,
    db: Session = Depends(get_db),
    user_id: int = Query(default=1),
):
    u = ensure_user(db, user_id)
    w = db.query(WeightLog).filter(WeightLog.id == weight_id, WeightLog.user_id == u.id).first()
    if not w:
        raise HTTPException(status_code=404, detail="Weight non trovato per questo utente")
    try:
        db.delete(w)
        db.commit()
        return {"ok": True, "deleted_weight_id": weight_id}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Errore delete_weight: {e}")

# ---------------- Plan (macros + distribuzioni) ----------------
@app.get("/plan")
def get_plan(
    db: Session = Depends(get_db),
    user_id: int = Query(default=1, description="ID utente"),
):
    u = ensure_user(db, user_id)
    plan = db.query(UserPlan).filter_by(user_id=u.id).first()
    if not plan:
        # crea piano default e distribuzioni default
        plan = UserPlan(
            user_id=u.id,
            on_kcal=2600,
            on_carb=360,
            on_pro=194,
            on_fat=45,
            off_kcal=2200,
            off_carb=200,
            off_pro=194,
            off_fat=55,
        )
        db.add(plan)
        db.flush()

        on_names = ["pre-workout", "intra-workout", "post-workout", "pranzo", "snack", "cena"]
        off_names = ["colazione", "spuntino mattina", "pranzo", "spuntino pomeriggio", "cena"]
        for i, n in enumerate(on_names):
            db.add(UserDistribution(plan_id=plan.id, is_on=True, name=n, sort_order=i))
        for i, n in enumerate(off_names):
            db.add(UserDistribution(plan_id=plan.id, is_on=False, name=n, sort_order=i))
        db.commit()
        db.refresh(plan)

    dists = (
        db.query(UserDistribution)
        .filter(UserDistribution.plan_id == plan.id)
        .order_by(UserDistribution.is_on.desc(), UserDistribution.sort_order.asc())
        .all()
    )

    return {
        "on_distributions": [d.name for d in dists if d.is_on],
        "off_distributions": [d.name for d in dists if not d.is_on],
        "on_limits": {"kcal": plan.on_kcal, "carb": plan.on_carb, "pro": plan.on_pro, "fat": plan.on_fat},
        "off_limits": {"kcal": plan.off_kcal, "carb": plan.off_carb, "pro": plan.off_pro, "fat": plan.off_fat},
    }

@app.put("/plan")
def update_plan(
    payload: PlanPayload,
    db: Session = Depends(get_db),
    user_id: int = Query(default=1, description="ID utente"),
):
    u = ensure_user(db, user_id)
    plan = db.query(UserPlan).filter_by(user_id=u.id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Nessun piano trovato per questo utente")

    # aggiorna limiti
    plan.on_kcal = payload.on_limits.kcal
    plan.on_carb = payload.on_limits.carb
    plan.on_pro = payload.on_limits.pro
    plan.on_fat = payload.on_limits.fat

    plan.off_kcal = payload.off_limits.kcal
    plan.off_carb = payload.off_limits.carb
    plan.off_pro = payload.off_limits.pro
    plan.off_fat = payload.off_limits.fat
    db.add(plan)
    db.flush()

    # reset & reinsert distribuzioni
    db.query(UserDistribution).filter(UserDistribution.plan_id == plan.id).delete(synchronize_session=False)
    for i, n in enumerate(payload.on_distributions):
        db.add(UserDistribution(plan_id=plan.id, is_on=True, name=n, sort_order=i))
    for i, n in enumerate(payload.off_distributions):
        db.add(UserDistribution(plan_id=plan.id, is_on=False, name=n, sort_order=i))

    db.commit()

    return {
        "on_distributions": payload.on_distributions,
        "off_distributions": payload.off_distributions,
        "on_limits": payload.on_limits.model_dump(),
        "off_limits": payload.off_limits.model_dump(),
    }

# ---------------- Debug ----------------
@app.get("/debug/pingdb")
def debug_pingdb(db: Session = Depends(get_db)):
    users = db.query(func.count(User.id)).scalar() or 0
    meals = db.query(func.count(Meal.id)).scalar() or 0
    workouts = db.query(func.count(Workout.id)).scalar() or 0
    weights = db.query(func.count(WeightLog.id)).scalar() or 0
    plans = db.query(func.count(UserPlan.id)).scalar() or 0
    return {
        "ok": True,
        "counts": {"users": users, "meals": meals, "workouts": workouts, "weights": weights, "plans": plans},
    }
