from pydantic import BaseModel, Field
from datetime import datetime
from typing import List

# -------------------------
# Meals
# -------------------------

class MealItemIn(BaseModel):
    food_name: str
    grams: float
    pro: float = 0
    carb: float = 0
    fat: float = 0

class MealIn(BaseModel):
    when: datetime = Field(default_factory=datetime.utcnow)
    items: List[MealItemIn]

# -------------------------
# Weights
# -------------------------

class WeightIn(BaseModel):
    when: datetime = Field(default_factory=datetime.utcnow)
    kg: float

# -------------------------
# Workouts
# -------------------------

class SetIn(BaseModel):
    exercise: str
    reps: int
    weight_kg: float = 0

class WorkoutIn(BaseModel):
    when: datetime = Field(default_factory=datetime.utcnow)
    sets: List[SetIn] = []

# -------------------------
# Plan
# -------------------------

class PlanLimits(BaseModel):
    kcal: int
    carb: int
    pro: int
    fat: int

class PlanPayload(BaseModel):
    on_distributions: List[str] = Field(default_factory=list)
    off_distributions: List[str] = Field(default_factory=list)
    on_limits: PlanLimits
    off_limits: PlanLimits
